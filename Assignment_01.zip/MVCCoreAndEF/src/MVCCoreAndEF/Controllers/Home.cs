﻿using System;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MVCCoreAndEF.Models;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Assignment1.Controllers
{
    public class Home : Controller
    {
        private Assignment1DataContext _context;

        public Home(Assignment1DataContext contexts)
        {
            _context = contexts;
        }

        public IActionResult Index()
        {
            return View(_context.BlogPosts.ToList());
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(User users)
        {
            if (Request.Form["Role"] == "Admin")
            {
                users.RoleId = 2;
            }
            else
            {
                users.RoleId = 1;
            }

            var existing = (from u in _context.Users where (u.EmailAddress == users.EmailAddress) select u).FirstOrDefault();
            if (existing == null)
            {
                _context.Users.Add(users);
                _context.SaveChanges();
            }

            return RedirectToAction("Login");
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Authentication()
        {
            String email = Request.Form["EmailAddress"];
            String pass = Request.Form["Password"];

            var user = (from u in _context.Users where (u.EmailAddress == email && u.Password == pass) select u).FirstOrDefault();
            if (user != null)
            {
                HttpContext.Session.SetInt32("UserId", user.UserId);
                HttpContext.Session.SetInt32("RoleId", user.RoleId);
                HttpContext.Session.SetString("UserName", user.FirstName + " " + user.LastName);
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult DisplayFullBlogPost(int id)
        {
            var blogPost = (from item in _context.BlogPosts where item.BlogPostId == id select item).FirstOrDefault();
            if (blogPost != null)
            {
                BlogPostModel model = new BlogPostModel();
                model.blogPost = blogPost;
                model.comments = new List<CommentModel>();

                var commentList = (from item in _context.Comments where item.BlogPostId == id select item).ToList();
                foreach (Comment com in commentList)
                {
                    CommentModel c = new CommentModel();
                    c.comment = com;
                    var author = (from user in _context.Users where user.UserId == com.UserId select user).FirstOrDefault();
                    c.authorName = author.FirstName + " " + author.LastName;
                    model.comments.Add(c);
                }

                model.user = (from user in _context.Users where user.UserId == blogPost.UserId select user).FirstOrDefault();
                return View(model);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        public IActionResult DisplayFullBlogPost()
        {
            Comment comment = new MVCCoreAndEF.Models.Comment();
            comment.BlogPostId = Convert.ToInt32(Request.Form["BlogPostId"]);
            comment.UserId = (int)HttpContext.Session.GetInt32("UserId");
            comment.Content = Request.Form["Content"];

            _context.Comments.Add(comment);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult AddBlogPost()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddBlogPost(BlogPost posts)
        {
            posts.Posted = DateTime.Now;
            posts.UserId = Convert.ToInt32(HttpContext.Session.GetInt32("UserId"));

            _context.BlogPosts.Add(posts);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult EditBlogPost(int id)
        {
            var edits = (from u in _context.BlogPosts where u.BlogPostId == id select u).FirstOrDefault();
            return View(edits);
        }

        [HttpPost]
        public IActionResult EditBlogPost(BlogPost posts)
        {
            var id = Convert.ToInt32(Request.Form["BlogPostId"]);
            var postsEdit = (from u in _context.BlogPosts where u.BlogPostId == posts.BlogPostId select u).FirstOrDefault();

            if (postsEdit == null)
            {
                return RedirectToAction("Index");
            }

            postsEdit.Title = posts.Title;
            postsEdit.Content = posts.Content;
            _context.Entry(postsEdit).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult DeleteBlogPost(int id)
        {
            var deleteBlogs = (from m in _context.BlogPosts where m.BlogPostId == id select m).FirstOrDefault();
            var comments = (from m in _context.Comments where m.BlogPostId == id select m);
            if (comments != null)
            {
                deleteBlogs.Comments = (from m in _context.Comments where m.BlogPostId == id select m).Include(p => p.User).ToList();
            }

            foreach (var comment in deleteBlogs.Comments)
            {
                _context.Remove(comment);
            }
            _context.Remove(deleteBlogs);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
    }
}
