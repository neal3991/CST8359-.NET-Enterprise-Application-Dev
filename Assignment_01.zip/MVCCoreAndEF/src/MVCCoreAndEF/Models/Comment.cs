﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCCoreAndEF.Models
{
    public class Comment
    {
        [Key]
        public int CommentId
        {
            get;
            set;
        }

        [ForeignKey("BlogPostId")]
        public int BlogPostId
        {
            get;
            set;
        }

        [ForeignKey("UserId")]
        public int UserId
        {
            get;
            set;
        }

        [StringLength(2048)]
        public string Content
        {
            get;
            set;
        }
        public BlogPost BlogPost {
            get;
            set;
        }

        public User User {
            get;
            set;
        }
    }
}