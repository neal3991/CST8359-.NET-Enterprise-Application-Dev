﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCCoreAndEF.Models
{
    public class BlogPostModel
    {
        public Models.BlogPost blogPost { get; set; }
        public List<CommentModel> comments { get; set; }
        public Models.User user { get; set; }
    }

    public class CommentModel
    {
        public Comment comment { get; set; }
        public string authorName { get; set; }
    }
}