﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace AzureStorage.Models
{
    public class Photo
    {
        [Key]
        public int PhotoId
        {
            get;
            set;
        }
        [Required]
        public string FileName
        {
            get;
            set;
        }
        [Required]
        public string Url
        {
            get;
            set;
        }
    }
}
