﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using IntroductionToASP.NETMVCCore.Models;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace IntroductionToASP.NETMVCCore.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Razor()
        {
            return View();
        }

        [HttpGet]
        public IActionResult CreatePerson()
        {
            return View();
        }

        [HttpPost]
        public IActionResult DisplayPerson()
        {
            HttpContext.Session.SetString("firstName", Request.Form["firstName"]);
            HttpContext.Session.SetString("lastName", Request.Form["lastName"]);
            HttpContext.Session.SetString("age", Request.Form["age"]);
            HttpContext.Session.SetString("emailAddress", Request.Form["emailAddress"]);
            HttpContext.Session.SetString("dateOfBirth", Request.Form["dateOfBirth"]);
            HttpContext.Session.SetString("password", Request.Form["password"]); // note you probably wouldn't normally save this value
            HttpContext.Session.SetString("description", Request.Form["description"]);

            return View();
        }

        [HttpGet]
        public IActionResult Form()
        {
            return View();
        }

        [HttpPost]
        public IActionResult DisplayForm(LoginInformationModel model)
        {
            return View(model);
        }
    }
}
