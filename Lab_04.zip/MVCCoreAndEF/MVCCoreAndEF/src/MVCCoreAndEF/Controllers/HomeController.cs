﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MVCCoreAndEF.Models;

namespace MVCCoreAndEF.Controllers
{
    public class HomeController : Controller
    {
        private MoviesContext _movieContext;

        public HomeController(MoviesContext context)
        {
            _movieContext = context;
        }
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View(_movieContext.Movies.ToList());
        }

        public IActionResult AddMovie()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreateMovie(Movie moive)
        {
            _movieContext.Movies.Add(moive);
            _movieContext.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult EditMovie(int id)
        {
            var movieToUpdate = (from c in _movieContext.Movies where c.MovieId == id select c).FirstOrDefault();

            return View(movieToUpdate);
        }

        public IActionResult ModifyMovie(Movie movie)
        {
            var id = Convert.ToInt32(Request.Form["MovieId"]);

            var movieToUpdate = (from c in _movieContext.Movies where c.MovieId == id select c).FirstOrDefault();
            movieToUpdate.Title = movie.Title;
            movieToUpdate.SubTitle = movie.SubTitle;
            movieToUpdate.Description = movie.Description;
            movieToUpdate.Year = movie.Year;
            movieToUpdate.Rating = movie.Rating;

            _movieContext.SaveChanges();


            return RedirectToAction("Index");
        }
        public IActionResult DeleteMovie(int id)
        {
            var movieToDelete = (from c in _movieContext.Movies where c.MovieId == id select c).FirstOrDefault();
            _movieContext.Remove(movieToDelete);
            _movieContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
